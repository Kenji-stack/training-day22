cd frontend
npm run dev
