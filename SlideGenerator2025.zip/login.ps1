# Helper script to login to Google Cloud
$env:Path = "C:\Users\platypus2000jp\AppData\Local\Google\Cloud SDK\google-cloud-sdk\bin;" + $env:Path

Write-Host "Starting Google Cloud Authentication..."
gcloud auth login
gcloud config set project slide-generator-2025-deep
Write-Host "Login Complete. You can now run deploy.ps1"
