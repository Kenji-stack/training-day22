# Deployment Script for SlideGenerator2025

# Add gcloud to path (Agent fix)
$env:Path = "C:\Users\platypus2000jp\AppData\Local\Google\Cloud SDK\google-cloud-sdk\bin;" + $env:Path

$PROJECT_ID = "slide-generator-2025-deep"
$REGION = "us-central1"
$BACKEND_IMAGE = "gcr.io/$PROJECT_ID/backend"
$FRONTEND_IMAGE = "gcr.io/$PROJECT_ID/frontend"

# 1. Enable Services (First time only)
# gcloud services enable run.googleapis.com containerregistry.googleapis.com cloudbuild.googleapis.com vertexai.googleapis.com

# 2. Build and Deploy Backend
Write-Host "Building Backend..."
gcloud builds submit --tag $BACKEND_IMAGE ./backend

Write-Host "Deploying Backend..."
gcloud run deploy backend-service `
    --image $BACKEND_IMAGE `
    --platform managed `
    --region $REGION `
    --allow-unauthenticated `
    --memory 4Gi `
    --cpu 2

# Get Backend URL
$BACKEND_URL = gcloud run services describe backend-service --region $REGION --format 'value(status.url)'
Write-Host "Backend URL: $BACKEND_URL"

# 3. Build and Deploy Frontend
# Check if cloudbuild.yaml exists, otherwise use tag (fallback if yaml missing)
if (Test-Path "./frontend/cloudbuild.yaml") {
    # Parse credentials from .env.local
    $envPath = "./frontend/.env.local"
    if (Test-Path $envPath) {
        $envContent = Get-Content $envPath
        $FIREBASE_API_KEY = ($envContent | Where-Object { $_ -match "^NEXT_PUBLIC_FIREBASE_API_KEY=" } | ForEach-Object { $_.Split('=', 2)[1] }).Trim()
        $FIREBASE_AUTH_DOMAIN = ($envContent | Where-Object { $_ -match "^NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=" } | ForEach-Object { $_.Split('=', 2)[1] }).Trim()
        $FIREBASE_PROJECT_ID = ($envContent | Where-Object { $_ -match "^NEXT_PUBLIC_FIREBASE_PROJECT_ID=" } | ForEach-Object { $_.Split('=', 2)[1] }).Trim()
    } else {
        Write-Error "frontend/.env.local not found. Cannot deploy without Firebase config."
        exit 1
    }
    
    gcloud builds submit ./frontend --config ./frontend/cloudbuild.yaml `
        --substitutions=_API_URL=$BACKEND_URL,_FIREBASE_API_KEY=$FIREBASE_API_KEY,_FIREBASE_AUTH_DOMAIN=$FIREBASE_AUTH_DOMAIN,_FIREBASE_PROJECT_ID=$FIREBASE_PROJECT_ID
} else {
    # Fallback (won't have env var baked in properly but builds)
    gcloud builds submit --tag $FRONTEND_IMAGE ./frontend
}

Write-Host "Deploying Frontend..."
gcloud run deploy frontend-service `
    --image $FRONTEND_IMAGE `
    --platform managed `
    --region $REGION `
    --allow-unauthenticated `
    --set-env-vars NEXT_PUBLIC_API_URL=$BACKEND_URL

$FRONTEND_URL = gcloud run services describe frontend-service --region $REGION --format 'value(status.url)'

Write-Host "Deployment Complete!"
Write-Host "Frontend: $FRONTEND_URL"
Write-Host "Backend: $BACKEND_URL"
