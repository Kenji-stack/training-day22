'use client';

import { useState, useCallback } from 'react';

interface FileUploaderProps {
  onUploadComplete: (files: string[]) => void;
  buttonText?: string;
}

export default function FileUploader({ onUploadComplete, buttonText = "アップロード" }: FileUploaderProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadedCount, setUploadedCount] = useState(0);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setIsDragging(true);
    } else if (e.type === 'dragleave') {
      setIsDragging(false);
    }
  }, []);

  const handleFiles = async (fileList: FileList) => {
    setUploading(true);
    try {
      const uploadedIds = [];
      for (const file of Array.from(fileList)) {
        const formData = new FormData();
        formData.append('file', file);

        const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
        const res = await fetch(`${apiUrl}/api/upload`, {
          method: 'POST',
          body: formData,
        });
        const data = await res.json();
        if (data.status === 'uploaded') {
          uploadedIds.push(data.filename);
        }
      }
      setUploadedCount(uploadedIds.length);
      onUploadComplete(uploadedIds);
    } catch (err) {
      console.error("Upload failed", err);
    } finally {
      setUploading(false);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  }, []);

  return (
    <div
      className={`
        rounded-lg p-3 text-center transition-all duration-200 border border-dashed cursor-pointer
        ${isDragging ? 'border-blue-400 bg-blue-500/10' : 'border-slate-500 hover:border-slate-400 bg-slate-700/50'}
      `}
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
    >
      <div className="flex items-center justify-center gap-3">
        <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
        </svg>
        <span className="text-slate-300 text-sm">
          {uploading ? "アップロード中..." : "ドラッグ＆ドロップ または"}
        </span>
        <input
          type="file"
          multiple
          className="hidden"
          id="fileInput"
          onChange={(e) => e.target.files && handleFiles(e.target.files)}
        />
        <label
          htmlFor="fileInput"
          className="px-3 py-1 bg-slate-600 hover:bg-slate-500 text-white text-sm rounded cursor-pointer transition-colors"
        >
          選択
        </label>
      </div>
    </div>
  );
}
