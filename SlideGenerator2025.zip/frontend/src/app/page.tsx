'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import FileUploader from '@/components/FileUploader';

type Stage = 'input' | 'generating' | 'done';
type Mode = 'file' | 'prompt' | 'hybrid';

const modes: { id: Mode; label: string; icon: string; description: string }[] = [
  { id: 'file', label: 'ファイル', icon: '📁', description: 'アップロードした資料からスライドを生成' },
  { id: 'prompt', label: 'チャット', icon: '💬', description: 'テキスト指示のみでスライドを生成' },
  { id: 'hybrid', label: 'ハイブリッド', icon: '🔗', description: 'ファイル＋テキスト指示で生成' },
];

export default function Home() {
  const { user, loading, logout } = useAuth();
  const router = useRouter();
  const [stage, setStage] = useState<Stage>('input');
  const [mode, setMode] = useState<Mode>('prompt');
  const [topic, setTopic] = useState('');
  const [prompt, setPrompt] = useState('');
  const [files, setFiles] = useState<string[]>([]);
  const [downloadUrl, setDownloadUrl] = useState('');
  const [numSlides, setNumSlides] = useState(5);

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login');
    }
  }, [user, loading, router]);

  if (loading || !user) {
    return <div className="min-h-screen bg-slate-900 flex items-center justify-center text-white">Loading...</div>;
  }

  const handleUploadComplete = async (uploadedFiles: string[]) => {
    setFiles(uploadedFiles);
  };

  const canGenerate = () => {
    if (!topic.trim()) return false;
    if (mode === 'file' && files.length === 0) return false;
    if (mode === 'hybrid' && files.length === 0) return false;
    return true;
  };

  const handleGenerate = () => {
    if (!canGenerate()) {
      if (!topic.trim()) {
        alert('トピックを入力してください');
      } else if ((mode === 'file' || mode === 'hybrid') && files.length === 0) {
        alert('ファイルをアップロードしてください');
      }
      return;
    }
    startGeneration(topic, files, prompt, mode, numSlides);
  };

  const startGeneration = async (topic: string, files: string[], prompt: string, mode: string, numSlides: number) => {
    setStage('generating');
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
      const res = await fetch(`${apiUrl}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic,
          file_ids: files,
          prompt: prompt,
          mode: mode,
          num_slides: numSlides
        }),
      });
      const data = await res.json();
      if (data.status === 'completed') {
        setDownloadUrl(`${apiUrl}${data.download_url}`);
        setStage('done');
      }
    } catch (err) {
      console.error(err);
      setStage('input');
    }
  };

  const resetAll = () => {
    setStage('input');
    setTopic('');
    setPrompt('');
    setFiles([]);
    setDownloadUrl('');
    setNumSlides(5);
  };

  const showFileUploader = mode === 'file' || mode === 'hybrid';
  const showPromptInput = mode === 'prompt' || mode === 'hybrid';

  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-4 sm:p-6 bg-gradient-to-br from-indigo-950 via-slate-900 to-purple-950">
      {/* 背景のグロー効果 */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"></div>
      </div>

      <div className="relative w-full max-w-xl text-center space-y-6 z-10">
        {/* ヘッダー */}
        <div className="space-y-2">
          <div className="flex items-center justify-between w-full">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-full border border-white/10 backdrop-blur-sm">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
              <span className="text-xs text-slate-300">AI Powered</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs text-slate-400 hidden sm:inline">{user?.email}</span>
              <button onClick={logout} className="text-xs text-red-400 hover:text-red-300 border border-red-500/20 px-3 py-1 rounded-full hover:bg-red-500/10 transition-colors">
                ログアウト
              </button>
            </div>
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-white via-blue-100 to-purple-200 bg-clip-text text-transparent">
            スライドジェネレーター
          </h1>
          <p className="text-slate-400 text-sm sm:text-base">
            AIでプロフェッショナルなプレゼンを瞬時に作成
          </p>
        </div>

        {/* 入力画面 */}
        {stage === 'input' && (
          <div className="space-y-4 mt-6">
            {/* モード選択タブ */}
            <div className="bg-slate-800/50 backdrop-blur-xl rounded-2xl p-1.5 border border-white/10">
              <div className="grid grid-cols-3 gap-1">
                {modes.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setMode(m.id)}
                    aria-label={`${m.label}モードを選択`}
                    className={`relative py-2.5 px-3 rounded-xl text-sm font-medium transition-all duration-300 ${mode === m.id
                      ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg shadow-blue-500/25'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                      }`}
                  >
                    <span className="mr-1">{m.icon}</span>
                    {m.label}
                  </button>
                ))}
              </div>
            </div>

            {/* モード説明 */}
            <p className="text-slate-500 text-xs">
              {modes.find(m => m.id === mode)?.description}
            </p>

            {/* メインカード */}
            <div className="bg-slate-800/40 backdrop-blur-xl rounded-2xl p-5 border border-white/10 shadow-2xl space-y-4">
              {/* トピック入力 */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-white text-sm font-medium">
                  <span className="w-6 h-6 bg-blue-500/20 rounded-lg flex items-center justify-center text-xs">📌</span>
                  トピック
                  <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  placeholder="例：AIの未来、会社紹介、製品発表..."
                  className="w-full px-4 py-3 bg-slate-900/50 rounded-xl text-white placeholder-slate-500 outline-none border border-white/5 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 transition-all text-sm"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                />
              </div>

              {/* ファイルアップロード（file/hybridモード） */}
              {showFileUploader && (
                <div className="space-y-2 animate-fadeIn">
                  <label className="flex items-center gap-2 text-white text-sm font-medium">
                    <span className="w-6 h-6 bg-purple-500/20 rounded-lg flex items-center justify-center text-xs">📁</span>
                    参考資料
                    {mode === 'file' && <span className="text-red-400">*</span>}
                  </label>
                  <FileUploader
                    onUploadComplete={handleUploadComplete}
                    buttonText="ファイルをアップロード"
                  />
                  {files.length > 0 && (
                    <div className="flex items-center gap-2 text-green-400 text-sm bg-green-500/10 rounded-lg px-3 py-2">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      {files.length}個のファイルを追加済み
                    </div>
                  )}
                </div>
              )}

              {/* プロンプト入力（prompt/hybridモード） */}
              {showPromptInput && (
                <div className="space-y-2 animate-fadeIn">
                  <label className="flex items-center gap-2 text-white text-sm font-medium">
                    <span className="w-6 h-6 bg-green-500/20 rounded-lg flex items-center justify-center text-xs">💬</span>
                    詳細指示
                    <span className="text-slate-500 text-xs font-normal">（オプション）</span>
                  </label>
                  <textarea
                    placeholder="例：5枚のスライドで構成、シンプルなデザイン、グラフを含める..."
                    className="w-full px-4 py-3 bg-slate-900/50 rounded-xl text-white placeholder-slate-500 outline-none border border-white/5 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 transition-all resize-none text-sm"
                    rows={3}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                  />
                </div>
              )}

              {/* スライド枚数選択 */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-white text-sm font-medium">
                  <span className="w-6 h-6 bg-orange-500/20 rounded-lg flex items-center justify-center text-xs">📊</span>
                  スライド枚数
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="3"
                    max="15"
                    value={numSlides}
                    onChange={(e) => setNumSlides(parseInt(e.target.value))}
                    className="flex-1 h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                  />
                  <span className="w-12 text-center px-3 py-2 bg-slate-900/50 rounded-xl text-white font-bold border border-white/5">
                    {numSlides}
                  </span>
                </div>
              </div>
            </div>

            {/* 生成ボタン */}
            <button
              onClick={handleGenerate}
              disabled={!canGenerate()}
              className={`w-full py-4 rounded-2xl font-bold text-lg transition-all duration-300 ${!canGenerate()
                ? 'bg-slate-700/50 text-slate-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-white hover:scale-[1.02] hover:shadow-xl hover:shadow-purple-500/25 active:scale-[0.98]'
                }`}
            >
              <span className="flex items-center justify-center gap-2">
                <span>🚀</span>
                スライドを生成
              </span>
            </button>
          </div>
        )}

        {/* 生成中 */}
        {stage === 'generating' && (
          <div className="bg-slate-800/40 backdrop-blur-xl rounded-2xl p-10 border border-white/10 space-y-6">
            <div className="relative w-20 h-20 mx-auto">
              <div className="absolute inset-0 rounded-full border-4 border-purple-500/30"></div>
              <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-blue-500 animate-spin"></div>
              <div className="absolute inset-2 rounded-full border-4 border-transparent border-t-purple-500 animate-spin" style={{ animationDuration: '1.5s', animationDirection: 'reverse' }}></div>
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-bold text-white">生成中...</h2>
              <p className="text-slate-400">AIがスライドを作成しています</p>
            </div>
            <div className="flex justify-center gap-1">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"
                  style={{ animationDelay: `${i * 0.15}s` }}
                ></div>
              ))}
            </div>
          </div>
        )}

        {/* 完了 */}
        {stage === 'done' && (
          <div className="bg-slate-800/40 backdrop-blur-xl rounded-2xl p-10 border border-green-500/30 space-y-6">
            <div className="w-20 h-20 mx-auto bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center shadow-lg shadow-green-500/25">
              <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-bold text-white">完成しました！</h2>
              <p className="text-slate-400">スライドの準備ができました</p>
            </div>
            <a
              href={downloadUrl}
              className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-2xl hover:scale-105 transition-all shadow-lg shadow-green-500/25"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              ダウンロード
            </a>
            <div>
              <button
                onClick={resetAll}
                className="text-slate-400 hover:text-white text-sm transition-colors"
                aria-label="新しいスライドを作成画面に戻る"
              >
                ← 別のスライドを作成
              </button>
            </div>
          </div>
        )}

        {/* フッター */}
        <p className="text-slate-600 text-xs">
          Powered by Gemini AI
        </p>
      </div>

      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }
      `}</style>
    </main>
  );
}
