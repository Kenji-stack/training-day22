import os
import json
from typing import List, Dict, Any
from pypdf import PdfReader
from pptx import Presentation
import google.generativeai as genai
# Configure pdf2image
from pdf2image import convert_from_path
from PIL import Image

class TextChunker:
    def chunk_file(self, file_path: str) -> List[Dict[str, Any]]:
        file_path_lower = file_path.lower()
        if file_path_lower.endswith('.pdf'):
            return self._chunk_pdf(file_path)
        elif file_path_lower.endswith('.pptx'):
            return self._chunk_pptx(file_path)
        else:
            return []

    def _chunk_pdf(self, file_path: str) -> List[Dict[str, Any]]:
        chunks = []
        try:
            reader = PdfReader(file_path)
            for i, page in enumerate(reader.pages):
                text = page.extract_text()
                if text:
                    chunks.append({
                        "text": text,
                        "metadata": {"source": os.path.basename(file_path), "page": i + 1}
                    })
        except Exception as e:
            print(f"Error chunking PDF: {e}")
        return chunks

    def _chunk_pptx(self, file_path: str) -> List[Dict[str, Any]]:
        chunks = []
        try:
            prs = Presentation(file_path)
            for i, slide in enumerate(prs.slides):
                text_content = []
                for shape in slide.shapes:
                    if hasattr(shape, "text"):
                        text_content.append(shape.text)
                
                full_text = "\n".join(text_content)
                if full_text.strip():
                     chunks.append({
                        "text": full_text,
                        "metadata": {"source": os.path.basename(file_path), "page": i + 1}
                    })
        except Exception as e:
            print(f"Error chunking PPTX: {e}")
        return chunks

class VisionGuidedChunker:
    """
    Advanced RAG chunker using Gemini 1.5 Flash to analyze page layouts.
    Requires 'poppler-utils' installed on the system for pdf2image.
    """
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        if self.api_key:
            genai.configure(api_key=self.api_key)
            self.model = genai.GenerativeModel('gemini-1.5-flash')
        else:
            print("Warning: GEMINI_API_KEY not found. VisionGuidedChunker will fail.")
            self.model = None

    def chunk_file(self, file_path: str) -> List[Dict[str, Any]]:
        if file_path.lower().endswith('.pdf'):
            return self._chunk_pdf_vision(file_path)
        else:
            # Fallback to text chunker for non-PDFs 
            return TextChunker().chunk_file(file_path)

    def _chunk_pdf_vision(self, file_path: str) -> List[Dict[str, Any]]:
        chunks = []
        try:
            print(f"DEBUG: Starting vision analysis for {file_path}")
            # convert_from_path requires poppler installed
            images = convert_from_path(file_path)
            
            for i, img in enumerate(images):
                print(f"DEBUG: Analyzing page {i+1} with Gemini Flash...")
                page_chunks = self._analyze_page(img, i + 1, os.path.basename(file_path))
                chunks.extend(page_chunks)
        except Exception as e:
            print(f"Vision chunking failed (poppler missing?): {e}")
            print("Falling back to standard TextChunker...")
            return TextChunker().chunk_file(file_path)
        return chunks

    def _analyze_page(self, image: Image.Image, page_num: int, source: str) -> List[Dict[str, Any]]:
        if not self.model:
            return []

        prompt = """
        Analyze this document page image. Extract the text content organized by logical sections.
        Return a JSON list of objects, where each object has:
        - "header": Section header or title (if any)
        - "content": Text content of the section, preserving important numbers and lists.
        - "type": "text", "table_summary", "image_caption", or "chart_analysis"
        
        Example JSON:
        [
            {"header": "Introduction", "content": "The study focuses on...", "type": "text"},
            {"header": "Figure 1 Analysis", "content": "Chart showing 20% growth...", "type": "chart_analysis"}
        ]
        """
        
        try:
            response = self.model.generate_content([prompt, image], generation_config={"response_mime_type": "application/json"})
            data = json.loads(response.text)
            
            page_chunks = []
            for item in data:
                header = item.get('header', '')
                content = item.get('content', '')
                chunk_type = item.get('type', 'text')
                
                text_content = f"[{chunk_type.upper()}] {header}\n{content}".strip()
                
                if content:
                    page_chunks.append({
                        "text": text_content,
                        "metadata": {
                            "source": source,
                            "page": page_num,
                            "type": chunk_type,
                            "header": header,
                            "is_vision_extracted": True
                        }
                    })
            return page_chunks
        except Exception as e:
            print(f"Page analysis failed: {e}")
            return []
