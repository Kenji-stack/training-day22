from qdrant_client import QdrantClient
from qdrant_client.http import models
from typing import List, Dict, Any
import uuid

class VectorStore:
    """
    Qdrantを使用したインメモリベクトルストア。
    """
    def __init__(self, collection_name: str = "slides_context", vector_size: int = 768):
        # Initialize in-memory Qdrant
        self.client = QdrantClient(":memory:")
        self.collection_name = collection_name
        self.vector_size = vector_size
        
        if self.client.collection_exists(self.collection_name):
            self.client.delete_collection(self.collection_name)
            
        self.client.create_collection(
            collection_name=self.collection_name,
            vectors_config=models.VectorParams(
                size=self.vector_size,
                distance=models.Distance.COSINE
            )
        )

    def add_chunks(self, chunks: List[Dict[str, Any]], embeddings: List[List[float]]):
        """
        チャンクと埋め込みベクトルを追加する。
        """
        if not chunks or not embeddings:
            return
            
        points = []
        for i, (chunk, vector) in enumerate(zip(chunks, embeddings)):
            # ベクトルの次元チェック
            if len(vector) != self.vector_size:
                if len(vector) > self.vector_size:
                    vector = vector[:self.vector_size]
                else:
                    vector = vector + [0.0] * (self.vector_size - len(vector))

            points.append(models.PointStruct(
                id=str(uuid.uuid4()),
                vector=vector,
                payload={
                    "text": chunk["text"],
                    "metadata": chunk["metadata"]
                }
            ))
            
        self.client.upsert(
            collection_name=self.collection_name,
            points=points
        )
        print(f"Index updated: Added {len(points)} chunks.")

    def search(self, query_vector: List[float], limit: int = 5) -> List[Dict[str, Any]]:
        """
        クエリベクトルに類似したチャンクを検索する。
        """
        if len(query_vector) != self.vector_size:
             if len(query_vector) > self.vector_size:
                query_vector = query_vector[:self.vector_size]
             else:
                query_vector = query_vector + [0.0] * (self.vector_size - len(query_vector))

        # searchメソッドがないため query_points を使用
        results = self.client.query_points(
            collection_name=self.collection_name,
            query=query_vector,
            limit=limit
        ).points
        
        return [
            {
                "text": hit.payload["text"],
                "metadata": hit.payload["metadata"],
                "score": hit.score
            }
            for hit in results
        ]
    
    def clear(self):
        """インデックスをクリアする"""
        if self.client.collection_exists(self.collection_name):
            self.client.delete_collection(self.collection_name)
            
        self.client.create_collection(
            collection_name=self.collection_name,
            vectors_config=models.VectorParams(
                size=self.vector_size,
                distance=models.Distance.COSINE
            )
        )
