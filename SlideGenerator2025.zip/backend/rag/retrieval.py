import torch
import torch.nn.functional as F

class MaxSimRetriever:
    def __init__(self):
        pass

    def compute_score(self, query_emb: torch.Tensor, doc_emb: torch.Tensor) -> float:
        """
        Compute MaxSim score between query and document embeddings.
        
        Args:
            query_emb: (1, num_query_tokens, dim)
            doc_emb: (1, num_doc_patches, dim)
            
        Returns:
            MaxSim score (float)
        """
        # query_emb: [1, Q, D]
        # doc_emb: [1, P, D]
        
        # Calculate similarity matrix: [1, Q, P]
        # We assume normalized embeddings if using dot product, otherwise cosine similarity
        # Here we implement standard dot product late interaction
        
        # Ensure shapes
        if query_emb.dim() == 2:
            query_emb = query_emb.unsqueeze(0)
        if doc_emb.dim() == 2:
            doc_emb = doc_emb.unsqueeze(0)
            
        # Sim(q, d) = sum_i(max_j(q_i @ d_j))
        
        # [1, Q, D] @ [1, D, P] -> [1, Q, P]
        interaction_matrix = torch.bmm(query_emb, doc_emb.transpose(1, 2))
        
        # Max over document patches (dim=2)
        max_scores_per_query_token, _ = interaction_matrix.max(dim=2) # [1, Q]
        
        # Sum over query tokens (dim=1)
        total_score = max_scores_per_query_token.sum(dim=1) # [1]
        
        return total_score.item()

    def search(self, query_emb: torch.Tensor, doc_embeddings: list[torch.Tensor], top_k: int = 5):
        scores = []
        for idx, doc_emb in enumerate(doc_embeddings):
            score = self.compute_score(query_emb, doc_emb)
            scores.append((score, idx))
        
        scores.sort(key=lambda x: x[0], reverse=True)
        return scores[:top_k]
