import google.generativeai as genai
import os
from typing import List

class GeminiEmbedder:
    """
    Gemini APIを使用してテキスト埋め込みを生成するクラス。
    """
    def __init__(self, model_name: str = "models/text-embedding-004"):
        self.model_name = model_name
        self.api_key = os.getenv("GEMINI_API_KEY")
        if self.api_key:
            genai.configure(api_key=self.api_key)
        else:
            print("Warning: GEMINI_API_KEY not found in environment. Embeddings will be mock.")

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """
        ドキュメントのリストを埋め込みベクトルのリストに変換する。
        """
        if not texts or not self.api_key:
            # Mock or empty
            return [[0.1] * 768 for _ in texts]
        
        embeddings = []
        batch_size = 20 # Gemini limit 100, safe margin
        
        try:
            for i in range(0, len(texts), batch_size):
                batch = texts[i:i + batch_size]
                result = genai.embed_content(
                    model=self.model_name,
                    content=batch,
                    task_type="retrieval_document"
                )
                if 'embedding' in result:
                    embeddings.append(result['embedding'])
                elif 'embeddings' in result:
                    embeddings.extend(result['embeddings'])
        except Exception as e:
            print(f"Embedding error: {e}")
            # Return something to prevent crash
            return [[0.1] * 768 for _ in texts]
            
        return embeddings

    def embed_query(self, text: str) -> List[float]:
        """
        クエリテキストを埋め込みベクトルに変換する。
        """
        if not self.api_key:
            return [0.1] * 768

        try:
            result = genai.embed_content(
                model=self.model_name,
                content=text,
                task_type="retrieval_query"
            )
            return result['embedding']
        except Exception as e:
            print(f"Query embedding error: {e}")
            return [0.1] * 768
