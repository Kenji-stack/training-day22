import torch
from PIL import Image
from typing import List, Union
import numpy as np

# Try to import colpali, handle if not installed
try:
    from transformers import AutoProcessor, ColPaliForRetrieval
    COLPALI_AVAILABLE = True
except ImportError:
    COLPALI_AVAILABLE = False
    print("ColPali libraries not found. Install transformers and torch.")

class VLMEncoder:
    def __init__(self, model_name: str = "vidore/colpali-v1.2", device: str = "cpu"):
        self.device = device
        self.model_name = model_name
        self.model = None
        self.processor = None
        
        if COLPALI_AVAILABLE:
            print(f"Loading ColPali model: {model_name}")
            # Note: In a real deployment, we would load to GPU (cuda/mps)
            # self.model = ColPaliForRetrieval.from_pretrained(model_name).to(self.device)
            # self.processor = AutoProcessor.from_pretrained(model_name)
            pass

    def encode_query(self, query: str) -> torch.Tensor:
        """
        Encode text query into embeddings.
        Returns: Tensor of shape (1, num_tokens, dim)
        """
        if not self.model:
            # Mock return for development environment without heavy weights
            return torch.randn(1, 10, 128) 
            
        inputs = self.processor(text=[query], return_tensors="pt").to(self.device)
        with torch.no_grad():
            embeddings = self.model(**inputs).last_hidden_state
        return embeddings

    def encode_image(self, images: List[Image.Image]) -> torch.Tensor:
        """
        Encode images into patch embeddings.
        Returns: Tensor of shape (batch, num_patches, dim)
        """
        if not self.model:
            # Mock return
            return torch.randn(len(images), 32, 128)

        inputs = self.processor(images=images, return_tensors="pt").to(self.device)
        with torch.no_grad():
            embeddings = self.model(**inputs).last_hidden_state
        return embeddings
