from pptx import Presentation
from pptx.util import Inches, Pt
import os

class PPTXBuilder:
    def __init__(self):
        self.prs = Presentation()

    def add_title_slide(self, title: str, subtitle: str):
        slide_layout = self.prs.slide_layouts[0] # Title Slide
        slide = self.prs.slides.add_slide(slide_layout)
        title_placeholder = slide.shapes.title
        subtitle_placeholder = slide.placeholders[1]

        title_placeholder.text = title
        subtitle_placeholder.text = subtitle

    def add_content_slide(self, title: str, content: list[str], image_path: str = None):
        """
        Adds a slide with title, bullet points, and optional image.
        Using layout 1 (Title and Content) or custom layout.
        """
        slide_layout = self.prs.slide_layouts[1] 
        slide = self.prs.slides.add_slide(slide_layout)
        
        # Title
        title_shape = slide.shapes.title
        title_shape.text = title
        
        # Content (Bullets)
        body_shape = slide.placeholders[1]
        tf = body_shape.text_frame
        tf.word_wrap = True
        
        if content:
            tf.text = content[0]
            for point in content[1:]:
                p = tf.add_paragraph()
                p.text = point
                p.level = 0

        # Image
        if image_path and os.path.exists(image_path):
            # Add image on the right side or bottom
            # Adjusting layout for image
            left = Inches(5.5)
            top = Inches(2)
            height = Inches(4.5)
            slide.shapes.add_picture(image_path, left, top, height=height)

    def save(self, filename: str):
        self.prs.save(filename)
