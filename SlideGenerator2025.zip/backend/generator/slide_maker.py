import json
import os
from typing import List, Dict, Optional
from .image_gen import ImageGenerator
from .pptx_builder import PPTXBuilder

# Gemini API
try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False
    print("google-generativeai not installed. Run: pip install google-generativeai")


class SlideMaker:
    def __init__(self, project_id: str):
        self.image_gen = ImageGenerator(project_id=project_id)
        self.model = None
        
        if GEMINI_AVAILABLE:
            api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
            if api_key:
                genai.configure(api_key=api_key)
                self.model = genai.GenerativeModel("gemini-2.0-flash")
                print("Gemini API initialized successfully")
            else:
                print("Warning: GEMINI_API_KEY not found in environment")

    def _generate_outline(self, topic: str, context: str, num_slides: int = 5) -> List[Dict]:
        """
        Gemini APIを使用してスライドのアウトラインを生成
        """
        prompt = f"""あなたはプロのプレゼンテーションデザイナーです。
以下のトピックについて、{num_slides}枚のスライドのアウトラインを作成してください。

トピック: {topic}

追加コンテキスト:
{context if context else "なし"}

以下のJSON形式で出力してください（説明は不要、JSONのみ）:
[
  {{
    "slide_number": 1,
    "title": "スライドタイトル",
    "content": ["ポイント1", "ポイント2", "ポイント3"],
    "image_prompt": "このスライドに適した画像の英語での説明（プロフェッショナル、ビジネス向け）"
  }},
  ...
]

注意:
- 最初のスライドはタイトルスライド（概要）にしてください
- 最後のスライドはまとめにしてください
- 各スライドのcontentは3-5個のポイントを含めてください
- image_promptは英語で、16:9のビジネスプレゼンテーション向けの画像を生成するための説明にしてください
"""
        
        if not self.model:
            # Fallback to mock data if API not available
            return self._generate_mock_outline(topic, num_slides)
        
        try:
            response = self.model.generate_content(prompt)
            text = response.text.strip()
            
            # JSONを抽出（```json ... ``` の場合に対応）
            if "```json" in text:
                text = text.split("```json")[1].split("```")[0].strip()
            elif "```" in text:
                text = text.split("```")[1].split("```")[0].strip()
            
            slides_data = json.loads(text)
            return slides_data
            
        except Exception as e:
            print(f"Error generating outline with Gemini: {e}")
            return self._generate_mock_outline(topic, num_slides)

    def _generate_mock_outline(self, topic: str, num_slides: int) -> List[Dict]:
        """Gemini APIが利用できない場合のモックデータ"""
        slides = [
            {
                "slide_number": 1,
                "title": f"{topic} - 概要",
                "content": ["本プレゼンテーションの目的", "主要なポイントの紹介", "期待される成果"],
                "image_prompt": f"Professional business presentation cover slide about {topic}, modern minimalist design"
            }
        ]
        
        for i in range(2, num_slides):
            slides.append({
                "slide_number": i,
                "title": f"{topic} - セクション {i-1}",
                "content": [f"重要なポイント {j}" for j in range(1, 4)],
                "image_prompt": f"Business illustration for {topic} section {i-1}, professional style"
            })
        
        slides.append({
            "slide_number": num_slides,
            "title": "まとめと次のステップ",
            "content": ["主要な結論", "推奨アクション", "今後の展望"],
            "image_prompt": "Success and future growth business concept illustration"
        })
        
        return slides

    def _expand_slide_content(self, slide: Dict, topic: str) -> Dict:
        """
        各スライドのコンテンツを詳細化（オプション）
        """
        if not self.model:
            return slide
        
        prompt = f"""以下のスライドのポイントをより詳細で説得力のある内容に改善してください。

トピック: {topic}
スライドタイトル: {slide['title']}
現在のポイント: {slide['content']}

改善されたポイントを3-4個、JSON配列形式で出力してください（説明不要）:
["改善されたポイント1", "改善されたポイント2", "改善されたポイント3"]
"""
        
        try:
            response = self.model.generate_content(prompt)
            text = response.text.strip()
            
            if "```" in text:
                text = text.split("```")[1].split("```")[0].strip()
                if text.startswith("json"):
                    text = text[4:].strip()
            
            improved_content = json.loads(text)
            slide["content"] = improved_content
        except Exception as e:
            print(f"Content expansion failed: {e}")
        
        return slide

    def generate_slide_deck(
        self, 
        topic: str, 
        retrieved_context: str, 
        output_file: str,
        num_slides: int = 5,
        expand_content: bool = False
    ):
        """
        スライド生成のオーケストレーション
        1. アウトライン生成 (Gemini)
        2. 各スライドの画像生成 (Imagen/Mock)
        3. PPTX構築
        """
        print(f"DEBUG: === Generating slides for: {topic} ===")
        print(f"DEBUG: Context preview: {retrieved_context[:200] if retrieved_context else 'No context'}...")
        
        # 1. アウトライン生成
        print("DEBUG: Step 1: Generating outline with Gemini...")
        try:
            slides_data = self._generate_outline(topic, retrieved_context, num_slides)
            print(f"DEBUG: Generated {len(slides_data)} slides")
        except Exception as e:
            print(f"DEBUG: Error generating outline: {e}")
            raise
        
        # 2. コンテンツ拡張（オプション）
        if expand_content:
            print("DEBUG: Step 2: Expanding content...")
            slides_data = [self._expand_slide_content(s, topic) for s in slides_data]
        
        # 3. PPTX構築
        print("DEBUG: Step 3: Building PPTX...")
        try:
            builder = PPTXBuilder()
            
            # タイトルスライドを追加
            if slides_data:
                first_slide = slides_data[0]
                builder.add_title_slide(
                    first_slide.get("title", topic), 
                    "Generated by SlideGenerator2025 with Gemini AI"
                )
            
            # アセットディレクトリ
            assets_dir = "assets"
            os.makedirs(assets_dir, exist_ok=True)
            
            # 残りのスライドを追加
            for i, slide in enumerate(slides_data[1:], start=1):
                print(f"DEBUG: Processing slide {i + 1}/{len(slides_data)}: {slide.get('title', 'Untitled')}")
                
                # 画像生成
                img_filename = f"{assets_dir}/slide_{i}.png"
                image_prompt = slide.get("image_prompt", f"Professional illustration for {topic}")
                print(f"DEBUG: Generating image for slide {i} with prompt prefix: {image_prompt[:20]}...")
                try:
                    self.image_gen.generate_image(image_prompt, img_filename)
                    print(f"DEBUG: Image generated for slide {i}")
                except Exception as e:
                    print(f"DEBUG: Error generating image for slide {i}: {e}")
                    # Continue without image or with placeholder (handled inside generate_image usually but just in case)
                
                # スライド追加
                builder.add_content_slide(
                    slide.get("title", f"Slide {i + 1}"),
                    slide.get("content", []),
                    img_filename
                )
            
            # 4. 保存
            print(f"DEBUG: Step 4: Saving to {output_file}")
            builder.save(output_file)
            print("DEBUG: === Slide generation complete ===")
        
        except Exception as e:
            print(f"DEBUG: Error building PPTX: {e}")
            raise
            
        return output_file
