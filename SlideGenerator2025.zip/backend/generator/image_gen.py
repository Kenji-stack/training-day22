import os
from typing import List
from PIL import Image, ImageDraw, ImageFont

# Vertex AI (Imagen)
try:
    import vertexai
    from vertexai.preview.vision_models import ImageGenerationModel
    VERTEX_AI_AVAILABLE = True
except ImportError:
    VERTEX_AI_AVAILABLE = False
    print("vertexai not installed. Run: pip install google-cloud-aiplatform")

class ImageGenerator:
    def __init__(self, project_id: str = "slide-generator-2025-deep", location: str = "us-central1"):
        self.project_id = project_id
        self.location = location
        self.model = None
        self._initialized = False

    def _initialize_vertex_ai(self):
        """Vertex AIとモデルの遅延初期化"""
        if self._initialized:
            return

        if VERTEX_AI_AVAILABLE:
            try:
                print("DEBUG: Initializing Vertex AI...")
                vertexai.init(project=self.project_id, location=self.location)
                self.model = ImageGenerationModel.from_pretrained("imagen-3.0-generate-001")
                print(f"DEBUG: Imagen model initialized: {self.model._model_name}")
            except Exception as e:
                print(f"DEBUG: Vertex AI initialization failed: {e}")
                print("DEBUG: Falling back to dummy image generation.")
                self.model = None
        
        self._initialized = True

    def generate_image(self, prompt: str, output_path: str) -> str:
        """
        プロンプトから画像を生成して保存する。
        Imagenが利用できない場合はダミー画像を生成する。
        """
        print(f"DEBUG: Generating image for prompt: {prompt}")
        
        # 遅延初期化
        self._initialize_vertex_ai()
        
        if self.model:
            try:
                images = self.model.generate_images(
                    prompt=prompt,
                    number_of_images=1,
                    language="en", 
                    aspect_ratio="16:9",
                    safety_filter_level="block_some",
                )
                if images:
                    images[0].save(output_path)
                    print(f"DEBUG: Image saved to {output_path} (via Imagen)")
                    return output_path
            except Exception as e:
                print(f"DEBUG: Imagen generation failed: {e}")
                # Fallback to dummy
        
        # Fallback: Create a dummy image
        self._create_dummy_image(prompt, output_path)
        return output_path

    def _create_dummy_image(self, prompt: str, output_path: str):
        """ダミー画像を生成（PIL使用）"""
        img = Image.new('RGB', (1920, 1080), color = (73, 109, 137))
        d = ImageDraw.Draw(img)
        
        # テキストを描画（簡易的）
        try:
            # フォントは見つからない可能性があるのでデフォルトを使用
            font = ImageFont.load_default()
            # 大きく描画したいがデフォルトだと小さい。
            # 矩形を描画してプロンプトを表示している風にする
            d.rectangle([100, 100, 1820, 980], outline=(255, 255, 255), width=5)
            d.text((120, 120), f"Image Placeholder for:\n{prompt[:100]}...", fill=(255, 255, 255))
        except Exception as e:
            print(f"Dummy image drawing error: {e}")
            
        img.save(output_path)
        print(f"Dummy image saved to {output_path}")
