from qdrant_client import QdrantClient
from qdrant_client.http import models

try:
    print("Initializing QdrantClient...")
    client = QdrantClient(":memory:")
    
    print("Recreating collection...")
    client.recreate_collection(
        collection_name="test",
        vectors_config=models.VectorParams(size=4, distance=models.Distance.COSINE)
    )
    
    print("Upserting points...")
    client.upsert(
        collection_name="test",
        points=[models.PointStruct(id=1, vector=[0.1, 0.1, 0.1, 0.1], payload={})]
    )
    
    print(f"Available methods: {dir(client)}")
    print("Searching with query_points...")
    res = client.query_points(
        collection_name="test",
        query=[0.1, 0.1, 0.1, 0.1],
        limit=1
    )
    print("Success!")
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
