from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="SlideGenerator2025 API")

# CORS setup
origins = [
    "http://localhost:3000",
    "http://localhost:3001",
    # TODO: Add production URL here e.g. "https://your-cloud-run-service.a.run.app"
    "https://slidebuilder-4f136.web.app", # Firebase Hosting URL
    "https://test-slide-builder.web.app", # Test env URL
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from api.endpoints import router
app.include_router(router, prefix="/api")

@app.get("/")
async def root():
    return {"message": "SlideGenerator2025 API is running"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}
