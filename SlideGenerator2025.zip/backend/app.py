from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="SlideGenerator2025 API")

# CORS setup
import os

# CORS setup
# Get origins from environment variable (comma separated) or default to localhost
allowed_origins_env = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000,http://localhost:3001")
origins = allowed_origins_env.split(",")

# Add production URLs if not explicitly in env (for convenience during this refactor)
# Ideally these should be passed via env var in Cloud Run
origins.append("https://slidebuilder-4f136.web.app")
origins.append("https://test-slide-builder.web.app")
# Add the newly deployed URL dynamically if possible, or expect it in ALLOWED_ORIGINS

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from api.endpoints import router
app.include_router(router, prefix="/api")

@app.get("/")
async def root():
    return {"message": "SlideGenerator2025 API is running"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}
