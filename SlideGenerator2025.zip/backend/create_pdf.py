from reportlab.pdfgen import canvas
import os

def create_dummy_pdf(filename):
    c = canvas.Canvas(filename)
    c.drawString(100, 750, "Sample PDF for Slide Generator RAG Test")
    c.drawString(100, 700, "This is a document about AI Agents.")
    c.drawString(100, 680, "AI Agents can use tools to perform complex tasks.")
    c.drawString(100, 660, "RAG (Retrieval Augmented Generation) helps agents grounded in data.")
    c.drawString(100, 640, "Key features of AI Agents:")
    c.drawString(120, 620, "- Autonomy")
    c.drawString(120, 600, "- Tool use")
    c.drawString(120, 580, "- Planning")
    c.save()

if __name__ == "__main__":
    create_dummy_pdf("sample_rag.pdf")
    print("Created sample_rag.pdf")
