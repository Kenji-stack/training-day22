from fastapi import APIRouter, UploadFile, File, Form, BackgroundTasks
from pydantic import BaseModel
from typing import List
import shutil
import os
from fastapi.responses import FileResponse

# New RAG modules
from rag.chunking import TextChunker, VisionGuidedChunker
from rag.embeddings import GeminiEmbedder
from rag.vector_db import VectorStore

from generator.slide_maker import SlideMaker

router = APIRouter()

# Initialize services
slide_maker = SlideMaker(project_id="slide-generator-2025-deep")
# Use VisionGuidedChunker for Advanced RAG (falls back to TextChunker)
text_chunker = VisionGuidedChunker() 
embedder = GeminiEmbedder()
vector_store = VectorStore()

UPLOAD_DIR = "uploads"
OUTPUT_DIR = "outputs"
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

class GenerateRequest(BaseModel):
    topic: str
    file_ids: List[str] = []
    prompt: str = ""
    mode: str = "prompt" # file, prompt, hybrid
    num_slides: int = 5 

@router.post("/upload")
async def upload_file(files: List[UploadFile] = File(...)): # Note: frontend sends 'files' field
    saved_files = []
    
    # Simple MVP approach: Clear index on new upload batch to keep context fresh
    vector_store.clear()
    
    for file in files:
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        saved_files.append(file.filename)
        
        # RAG Indexing
        print(f"DEBUG: Processing file {file.filename} for RAG...")
        try:
            chunks = text_chunker.chunk_file(file_path)
            if chunks:
                print(f"DEBUG: Extracted {len(chunks)} chunks from {file.filename}")
                texts = [c["text"] for c in chunks]
                embeddings = embedder.embed_documents(texts)
                vector_store.add_chunks(chunks, embeddings)
            else:
                print(f"DEBUG: No text extraction from {file.filename}")
        except Exception as e:
            print(f"DEBUG: Indexing error for {file.filename}: {e}")
        finally:
            # Compliance: Remove file after processing to minimize data retention
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
                    print(f"DEBUG: Removed temporary file {file.filename}")
            except Exception as e:
                print(f"DEBUG: Failed to remove file {file.filename}: {e}")

    return {"uploaded_files": saved_files}

@router.post("/generate")
async def generate_slides(request: GenerateRequest, background_tasks: BackgroundTasks):
    print(f"Received request: {request}")
    
    num_slides = max(3, min(15, request.num_slides))
    
    # RAG Retrieval
    context = ""
    if request.mode in ["file", "hybrid"]:
        print(f"DEBUG: Performing RAG retrieval for topic: {request.topic}")
        try:
            # Topic embedding
            query_emb = embedder.embed_query(request.topic)
            
            # Combine topic embedding with prompt embedding if prompt exists (simple average or separate search)
            # For MVP, just search by topic as it's the main subject
            
            results = vector_store.search(query_emb, limit=5)
            
            if results:
                retrieved_texts = []
                for r in results:
                    source = r['metadata'].get('source', 'unknown')
                    page = r['metadata'].get('page', '?')
                    text = r['text']
                    retrieved_texts.append(f"Source: {source} (Page {page})\n{text}")
                
                context = "\n\n".join(retrieved_texts)
                print(f"DEBUG: Retrieved {len(results)} chunks for context")
            else:
                print("DEBUG: No relevant chunks found.")
                
        except Exception as e:
            print(f"DEBUG: Retrieval error: {e}")
            import traceback
            traceback.print_exc()

    # Add user instructions to context
    if request.prompt:
        context = f"{context}\n\nUser Instructions: {request.prompt}"

    # Generate Slides
    output_filename = f"{request.topic.replace(' ', '_')}.pptx"
    output_path = os.path.join(OUTPUT_DIR, output_filename)
    
    print(f"DEBUG: Calling generate_slide_deck with topic={request.topic}, num_slides={num_slides}")
    try:
        slide_maker.generate_slide_deck(
            request.topic, 
            context, 
            output_path,
            num_slides=num_slides
        )
        print(f"DEBUG: generate_slide_deck returned successfully")
    except Exception as e:
        print(f"DEBUG: Error in generate_slide_deck: {e}")
        import traceback
        traceback.print_exc()
        return {"status": "error", "message": str(e)}
    
    return {"status": "completed", "download_url": f"/download/{output_filename}"}

@router.get("/download/{filename}")
async def download_file(filename: str):
    file_path = os.path.join(OUTPUT_DIR, filename)
    if os.path.exists(file_path):
        return FileResponse(file_path, filename=filename)
    return {"error": "File not found"}
