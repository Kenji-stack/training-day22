Write-Host "Installing Google Cloud SDK..."
winget install Google.CloudSDK --silent --accept-source-agreements --accept-package-agreements
if ($LASTEXITCODE -eq 0) {
    Write-Host "Installation successful."
    Write-Host "Please restart your terminal (or refresh environment variables) and run 'gcloud auth login'."
} else {
    Write-Host "Installation failed. Please download manually from https://cloud.google.com/sdk/docs/install"
}
