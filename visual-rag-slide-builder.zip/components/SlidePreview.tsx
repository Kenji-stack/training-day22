import React from 'react';
import { SlideContent } from '../types';
import { Loader2, RefreshCw } from 'lucide-react';

interface SlidePreviewProps {
  slide: SlideContent;
  index: number;
  onRegenerateImage: (id: string, prompt: string) => void;
  isRegeneratingImage: boolean;
}

export const SlidePreview: React.FC<SlidePreviewProps> = ({ 
  slide, 
  index, 
  onRegenerateImage, 
  isRegeneratingImage 
}) => {
  return (
    <div className="bg-white aspect-video w-full shadow-lg rounded-lg overflow-hidden relative flex flex-col border border-slate-200">
      <div className="absolute top-2 right-2 text-xs text-slate-300 font-mono">#{index + 1}</div>
      
      {/* Title Area */}
      <div className="p-6 pb-2">
        <h2 className="text-2xl font-bold text-slate-800 leading-tight">{slide.title}</h2>
        <div className="w-16 h-1 bg-indigo-500 mt-2 rounded-full"></div>
      </div>

      <div className="flex-1 p-6 pt-2 flex gap-4">
        {/* Left Content (Text) */}
        <div className={`flex-1 flex flex-col ${slide.generatedImageUrl ? 'w-1/2' : 'w-full'}`}>
          <ul className="space-y-2 mt-2">
            {slide.bulletPoints.map((point, idx) => (
              <li key={idx} className="flex items-start text-slate-600 text-sm md:text-base">
                <span className="mr-2 text-indigo-500">•</span>
                {point}
              </li>
            ))}
          </ul>
        </div>

        {/* Right Content (Image) */}
        {slide.generatedImageUrl && (
          <div className="w-1/2 relative group">
             <div className="w-full h-full rounded-md overflow-hidden bg-slate-100 flex items-center justify-center border border-slate-100">
                <img 
                  src={slide.generatedImageUrl} 
                  alt="Slide visual" 
                  className="w-full h-full object-cover"
                />
             </div>
             
             {/* Regenerate Button Overlay */}
             <button
               onClick={() => onRegenerateImage(slide.id, slide.imagePrompt)}
               disabled={isRegeneratingImage}
               className="absolute top-2 right-2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-50"
               title="Regenerate Image"
             >
               {isRegeneratingImage ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
             </button>
          </div>
        )}
      </div>

      {/* Footer / Notes hint */}
      <div className="bg-slate-50 px-6 py-2 border-t border-slate-100 text-xs text-slate-400 truncate">
        Speaker Notes: {slide.speakerNotes}
      </div>
    </div>
  );
};
