export interface SlideContent {
  id: string;
  title: string;
  bulletPoints: string[];
  speakerNotes: string;
  imagePrompt: string;
  generatedImageUrl?: string; // Base64 or URL
  layout: 'title' | 'content_right' | 'content_left' | 'bullets_only';
}

export interface UploadedFile {
  id: string;
  name: string;
  type: string;
  content: string | ArrayBuffer | null; // Base64 for images/PDF pages
  previewUrl?: string;
  pages?: string[]; // Array of Base64 strings for PDF pages
}

export enum AppState {
  UPLOAD = 'UPLOAD',
  ANALYZING = 'ANALYZING',
  EDITING = 'EDITING',
  EXPORTING = 'EXPORTING'
}
