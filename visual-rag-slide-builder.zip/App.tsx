import React, { useState, useEffect, useRef } from 'react';
import { 
  Upload, FileText, Image as ImageIcon, Sparkles, 
  Download, FileUp, Loader2, PlayCircle, Settings
} from 'lucide-react';
import { convertPdfToImages, fileToBase64 } from './utils/pdfProcessor';
import { analyzeDocumentsAndGenerateStructure, generateSlideImage } from './services/geminiService';
import { exportToPptx } from './services/exportService';
import { AppState, SlideContent, UploadedFile } from './types';
import { SlidePreview } from './components/SlidePreview';

const App = () => {
  const [apiKey, setApiKey] = useState<string>(process.env.API_KEY || '');
  const [appState, setAppState] = useState<AppState>(AppState.UPLOAD);
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [slides, setSlides] = useState<SlideContent[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [generatingImageId, setGeneratingImageId] = useState<string | null>(null);

  // Helper to handle file selection
  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files) return;
    
    setIsProcessing(true);
    setStatusMessage('ドキュメントを読み込み中...');

    const newFiles: UploadedFile[] = [];
    
    try {
      const fileList = Array.from(event.target.files) as File[];
      for (const file of fileList) {
        if (file.type === 'application/pdf') {
          setStatusMessage(`${file.name} を画像に変換中 (Visual Encoding)...`);
          const pages = await convertPdfToImages(file);
          newFiles.push({
            id: crypto.randomUUID(),
            name: file.name,
            type: 'pdf',
            content: null,
            pages: pages,
            previewUrl: pages[0] // Preview first page
          });
        } else if (file.type.startsWith('image/')) {
          const b64 = await fileToBase64(file);
          newFiles.push({
            id: crypto.randomUUID(),
            name: file.name,
            type: 'image',
            content: b64,
            pages: [b64],
            previewUrl: b64
          });
        }
      }
      setFiles(prev => [...prev, ...newFiles]);
    } catch (e) {
      console.error(e);
      alert("ファイルの読み込みに失敗しました。");
    } finally {
      setIsProcessing(false);
      setStatusMessage('');
    }
  };

  // Main Logic: Analyze and Generate Structure
  const handleGenerateStructure = async () => {
    if (!apiKey) {
      alert("APIキーを入力してください");
      return;
    }
    if (files.length === 0) return;

    setAppState(AppState.ANALYZING);
    setIsProcessing(true);
    setStatusMessage('Visual RAGを実行中: ドキュメント構造を解析しています...');

    try {
      // Collect all pages from all files
      const allPages = files.flatMap(f => f.pages || []);
      
      const generatedSlides = await analyzeDocumentsAndGenerateStructure(allPages, apiKey);
      setSlides(generatedSlides);
      setAppState(AppState.EDITING);
      
      // Auto-trigger image generation for the first slide to show capability? 
      // Or let user do it manually. Let's do a bulk generation trigger but handle it sequentially.
      generateImagesSequentially(generatedSlides);

    } catch (e) {
      console.error(e);
      alert("解析に失敗しました。しばらく待ってから再試行してください。");
      setAppState(AppState.UPLOAD);
    } finally {
      setIsProcessing(false);
    }
  };

  // Background Process: Generate images one by one
  const generateImagesSequentially = async (initialSlides: SlideContent[]) => {
    const slidesToProcess = [...initialSlides];
    
    for (let i = 0; i < slidesToProcess.length; i++) {
        const slide = slidesToProcess[i];
        if (!slide.generatedImageUrl) {
            setGeneratingImageId(slide.id);
            try {
                const imgData = await generateSlideImage(slide.imagePrompt, apiKey);
                setSlides(prev => prev.map(s => s.id === slide.id ? { ...s, generatedImageUrl: imgData } : s));
            } catch (e) {
                console.warn(`Failed to generate image for slide ${i}`);
            }
        }
    }
    setGeneratingImageId(null);
  };

  const handleRegenerateImage = async (slideId: string, prompt: string) => {
    setGeneratingImageId(slideId);
    try {
      const imgData = await generateSlideImage(prompt, apiKey);
      setSlides(prev => prev.map(s => s.id === slideId ? { ...s, generatedImageUrl: imgData } : s));
    } catch (e) {
      alert("画像生成に失敗しました");
    } finally {
      setGeneratingImageId(null);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="bg-indigo-600 p-2 rounded-lg">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600">
              Visual RAG Slide Builder
            </h1>
          </div>
          
          <div className="flex items-center gap-4">
             {appState === AppState.EDITING && (
                <button 
                  onClick={() => exportToPptx(slides)}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md transition-colors text-sm font-medium"
                >
                  <Download className="w-4 h-4" />
                  PPTX ダウンロード
                </button>
             )}
          </div>
        </div>
      </header>

      {/* API Key Modal / Input if missing */}
      {!apiKey && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
           <div className="bg-white rounded-xl shadow-2xl p-6 max-w-md w-full">
              <h2 className="text-lg font-bold mb-4">API設定</h2>
              <p className="text-sm text-slate-600 mb-4">
                Google Gemini APIキーを入力してください。Gemini 2.5 Flashを使用します。
              </p>
              <input 
                type="password" 
                placeholder="AIzaSy..." 
                className="w-full border border-slate-300 rounded-md p-2 mb-4 focus:ring-2 focus:ring-indigo-500 outline-none"
                onChange={(e) => setApiKey(e.target.value)}
              />
              <p className="text-xs text-slate-500 mb-4">
                ※ APIキーはブラウザ内でのみ使用され、外部サーバーには保存されません。
              </p>
           </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8">
        
        {/* Step 1: Upload */}
        {appState === AppState.UPLOAD && (
          <div className="max-w-2xl mx-auto text-center space-y-8 mt-10">
            <div className="space-y-4">
              <h2 className="text-3xl font-bold text-slate-800">ドキュメントからスライドを自動生成</h2>
              <p className="text-slate-600 text-lg">
                ColPali等の視覚情報に基づいたRAGアーキテクチャを採用。<br/>
                PDFや画像をアップロードすると、Gemini 2.5がレイアウトを解析し、プレゼンを作成します。
              </p>
            </div>

            <div className="border-2 border-dashed border-slate-300 rounded-xl p-12 bg-white hover:bg-slate-50 transition-colors relative group cursor-pointer">
              <input 
                type="file" 
                multiple 
                accept="application/pdf,image/*" 
                onChange={handleFileChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                disabled={isProcessing}
              />
              <div className="flex flex-col items-center gap-4">
                {isProcessing ? (
                  <Loader2 className="w-12 h-12 text-indigo-500 animate-spin" />
                ) : (
                  <FileUp className="w-12 h-12 text-indigo-400 group-hover:scale-110 transition-transform" />
                )}
                <div>
                  <p className="font-semibold text-slate-700">クリックしてファイルをアップロード</p>
                  <p className="text-sm text-slate-500">PDF, PNG, JPG (最大 20ページ推奨)</p>
                </div>
              </div>
            </div>

            {statusMessage && (
               <div className="text-indigo-600 font-medium animate-pulse">
                 {statusMessage}
               </div>
            )}

            {files.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 text-left">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <FileText className="w-4 h-4" /> 読み込み済みファイル ({files.length})
                </h3>
                <div className="flex flex-wrap gap-4 mb-6">
                  {files.map(f => (
                    <div key={f.id} className="relative w-24 h-32 bg-slate-100 rounded border overflow-hidden group">
                        {f.previewUrl ? (
                          <img src={f.previewUrl} className="w-full h-full object-cover opacity-80" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-xs text-slate-400">PDF</div>
                        )}
                        <div className="absolute inset-0 flex items-end p-1 bg-gradient-to-t from-black/50 to-transparent">
                          <span className="text-xs text-white truncate w-full">{f.name}</span>
                        </div>
                    </div>
                  ))}
                </div>
                
                <button
                  onClick={handleGenerateStructure}
                  disabled={isProcessing || !apiKey}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white py-3 rounded-lg font-bold text-lg shadow-lg shadow-indigo-200 transition-all flex items-center justify-center gap-2"
                >
                  {isProcessing ? <Loader2 className="animate-spin" /> : <Sparkles className="w-5 h-5" />}
                  スライド生成を開始 (RAG Analysis)
                </button>
              </div>
            )}
          </div>
        )}

        {/* Step 2: Analyzing Loading State */}
        {appState === AppState.ANALYZING && (
          <div className="flex flex-col items-center justify-center h-96 space-y-6">
            <div className="relative">
              <div className="w-16 h-16 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-indigo-600" />
              </div>
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-xl font-bold text-slate-800">ドキュメントを解析中...</h3>
              <p className="text-slate-500 max-w-md">
                Gemini 2.5 Flashが視覚情報とテキスト構造を統合し、最適なスライド構成を考えています。
              </p>
            </div>
          </div>
        )}

        {/* Step 3: Editor / Preview */}
        {appState === AppState.EDITING && (
          <div className="space-y-8">
            <div className="flex justify-between items-end">
              <div>
                <h2 className="text-2xl font-bold text-slate-800">生成されたスライド</h2>
                <p className="text-slate-500 text-sm">
                  {generatingImageId 
                    ? "AI画像生成中... バックグラウンドで処理しています" 
                    : "すべての画像生成が完了しました"}
                </p>
              </div>
              <button 
                onClick={() => setAppState(AppState.UPLOAD)}
                className="text-slate-500 hover:text-slate-800 text-sm underline"
              >
                最初からやり直す
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 gap-8">
              {slides.map((slide, idx) => (
                <SlidePreview 
                  key={slide.id} 
                  slide={slide} 
                  index={idx} 
                  onRegenerateImage={handleRegenerateImage}
                  isRegeneratingImage={generatingImageId === slide.id}
                />
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;