import { SlideContent } from "../types";

declare const PptxGenJS: any;

export const exportToPptx = (slides: SlideContent[]) => {
  const pptx = new PptxGenJS();
  
  // Set Layout
  pptx.layout = 'LAYOUT_16x9';

  slides.forEach(slide => {
    const pptSlide = pptx.addSlide();
    
    // Background
    pptSlide.background = { color: 'F1F5F9' }; // Slate-50 equivalent

    // Title
    pptSlide.addText(slide.title, {
      x: 0.5, y: 0.5, w: '90%', h: 1,
      fontSize: 24, bold: true, color: '1e293b'
    });

    const hasImage = !!slide.generatedImageUrl;
    
    // Layout Logic
    if (slide.layout === 'title') {
         pptSlide.addText(slide.bulletPoints.join('\n'), {
             x: 1, y: 2, w: '80%', h: 3, fontSize: 18, align: 'center', color: '334155'
         });
    } else if (hasImage) {
        // Content Left, Image Right
        pptSlide.addText(slide.bulletPoints.map(b => `• ${b}`).join('\n'), {
            x: 0.5, y: 1.5, w: 4.5, h: 4,
            fontSize: 14, color: '334155', valign: 'top'
        });
        
        // Add Image
        // Note: data URLs need to be clean for pptxgenjs sometimes, but usually supports it.
        pptSlide.addImage({
            data: slide.generatedImageUrl,
            x: 5.2, y: 1.5, w: 4.5, h: 3.5
        });

    } else {
        // Bullets Full Width
        pptSlide.addText(slide.bulletPoints.map(b => `• ${b}`).join('\n'), {
            x: 0.5, y: 1.5, w: '90%', h: 4,
            fontSize: 16, color: '334155', valign: 'top'
        });
    }

    // Speaker Notes
    if (slide.speakerNotes) {
        pptSlide.addNotes(slide.speakerNotes);
    }
  });

  pptx.writeFile({ fileName: `Generated-Presentation-${new Date().toISOString().slice(0,10)}.pptx` });
};
