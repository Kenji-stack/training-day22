import { GoogleGenAI, Type } from "@google/genai";
import { SlideContent } from "../types";

// Helper to remove header from base64 if present
const cleanBase64 = (b64: string) => b64.replace(/^data:.+;base64,/, '');

export const analyzeDocumentsAndGenerateStructure = async (
  pageImages: string[], // Array of base64 images (PDF pages)
  apiKey: string
): Promise<SlideContent[]> => {
  const ai = new GoogleGenAI({ apiKey });
  
  // We use Gemini 2.5 Flash for its multimodal long context window.
  // This simulates "Vision-Guided Chunking" by letting the model see the layout.
  const model = "gemini-2.5-flash";

  const parts = [];
  
  // Add system instruction as text part
  parts.push({
    text: `あなたはプロフェッショナルなプレゼンテーション作成アシスタントです。
    提供されたドキュメント（スライド画像や文書画像）を分析し、プレゼンテーションスライドの構成を作成してください。
    
    以下のルールに従ってください：
    1. **視覚情報の統合**: 図表、グラフ、レイアウトから重要な情報を読み取り、スライドに反映してください。
    2. **要約と構造化**: 内容を論理的な流れ（導入、課題、解決策、詳細、結論など）に整理してください。
    3. **画像の提案**: 各スライドの内容を補完するAI画像生成用のプロンプト（英語）を作成してください。
    
    出力はJSON形式で、以下のスキーマに従ってください。`
  });

  // Add all document pages as inline data
  // Limit to first 20 pages to avoid hitting immediate payload limits in this demo, 
  // though Gemini 2.5 Flash can handle much more.
  const pagesToProcess = pageImages.slice(0, 20); 
  
  pagesToProcess.forEach(pageB64 => {
    parts.push({
      inlineData: {
        mimeType: "image/png",
        data: cleanBase64(pageB64)
      }
    });
  });

  const responseSchema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        title: { type: Type.STRING },
        bulletPoints: { 
          type: Type.ARRAY, 
          items: { type: Type.STRING } 
        },
        speakerNotes: { type: Type.STRING },
        imagePrompt: { type: Type.STRING, description: "Detailed English prompt to generate an image representing this slide's concept." },
        layout: { type: Type.STRING, enum: ['title', 'content_right', 'content_left', 'bullets_only'] }
      },
      required: ["title", "bulletPoints", "speakerNotes", "imagePrompt", "layout"]
    }
  };

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: parts
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        systemInstruction: "Output a JSON array of slides based on the visual document context."
      }
    });

    const jsonText = response.text || "[]";
    const parsedData = JSON.parse(jsonText);
    
    // Add IDs to the slides
    return parsedData.map((slide: any, index: number) => ({
      ...slide,
      id: `slide-${index}-${Date.now()}`
    }));

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw new Error("Failed to analyze documents. Please check your API key and try again.");
  }
};

export const generateSlideImage = async (prompt: string, apiKey: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey });
  const model = "gemini-2.5-flash-image"; // Efficient image generation

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [{ text: prompt }]
      }
    });

    // Check for inlineData (Base64) output which is typical for gemini-2.5-flash-image
    const imagePart = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
    
    if (imagePart && imagePart.inlineData && imagePart.inlineData.data) {
       return `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
    }
    
    throw new Error("No image data received");

  } catch (error) {
    console.error("Image Gen Error:", error);
    // Return a placeholder if generation fails to keep the app flow going
    return `https://picsum.photos/800/600?random=${Math.random()}`;
  }
};